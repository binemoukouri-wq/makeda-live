# MAKEDA Projection — source and backend handover

Prepared 14 October 2026. Developed by JUJUMAKE.

## What this package is
The current application source, backend API routes, database schema and SQL migrations, assets, PWA files, dependency manifest and lockfile. Includes the latest admin dashboard with separate contact columns, CSV export, username/password login, logout and the → navigation arrow. Paramètres and integration configuration notices have been removed.

This is a developer handover package, not a Netlify drag-and-drop deployment. No production database records, credentials, installed node_modules or hosting accounts are included. The live site is unaffected.

## Current architecture
React / Vinext, Cloudflare Workers runtime, D1 database accessed through Drizzle. The public frontend and /admin no longer require ChatGPT login. Admin access uses the application username/password session. The existing project identifier in .openai/hosting.json is retained for source provenance; it does not grant access or provision a new host.

## Install and build
Requires Node.js >=22.13.0 and pnpm 11.25.0 (see package.json).
From the source directory:

    pnpm install --frozen-lockfile
    pnpm run build

Dependencies are resolved by the included lockfile and downloaded during installation. See source/README.md for portable development, local database initialization and preview commands. The source build passed before this package was created. Deployment outside Sites has not been tested.

## Backend routes
- POST /api/leads: validate and store form submissions.
- POST /api/booking: record a requested appointment, not a confirmed calendar booking.
- GET /api/admin: authorised admin data.
- POST /api/admin: update lead status; existing configuration API retained.
- GET /api/admin/export: authenticated CSV export.
- GET /api/config: projection/product configuration.
- POST /api/events: usage events.

## Database and export
Run SQL migrations in source/drizzle in order against the target D1 database. They define structure only. Do not replay applied migrations. Bind the database as DB.
The leads table contains name, phone (WhatsApp), email, more_info, marketing, consent, investment details, source, timestamps, follow-up and appointment fields. Existing records default more_info to 0; this does not retrospectively record a newly collected preference.
CSV export is available to authorised administrators at /admin. It excludes private lead tokens. CSV headers are machine-readable; consent flags are 0/1. Spreadsheet formula protection may prefix phone numbers or risky strings with an apostrophe. Normalise phone fields deliberately when importing into a CRM.
A leads CSV is not a complete database backup: events, settings and private booking tokens are not included. Plan a full authorised data export separately if those are required.

## Independent hosting / transfer meeting
1. Confirm Makeda's target hosting, database/CRM and required field mapping.
2. Provision the runtime and database in the destination account.
3. Adapt deployment configuration to that provider. Cloudflare is the nearest runtime match; other runtimes require replacing cloudflare:workers/D1-specific access.
4. Preserve the application's server-side username/password authentication in lib/admin-auth.ts and its protected admin APIs. The /admin page does not rely on ChatGPT identity. Verify session cookies, expiry, logout and failed-login limits on the destination. This authentication must be active before exposing admin data.
5. Configure ADMIN_USERNAME, ADMIN_PASSWORD and ADMIN_SESSION_SECRET as server-side runtime secrets. Use the agreed admin username/password and a newly generated random session secret of at least 32 bytes. Do not put these values in browser code or version control. The current hosted secrets are deliberately excluded from this archive. Restart/redeploy after setting them.
6. Export production data through authorised access, import it, reconcile row counts and test a fresh lead plus CSV export.
7. Agree a cutover window and final data sync so submissions are not lost or duplicated.
8. Configure domain, HTTPS and staff access. Validate Makeda's public content and data-handling policy before public launch.

No email notification, calendar synchronisation or Makeda CRM connection is configured by this ZIP. The current live frontend is public. /admin shows the username/password form; admin data and CSV exports require a valid admin session. These public and protected routes were verified on the hosted site.

## Important source locations
- app/admin/dashboard.tsx: personnel dashboard
- app/api/: backend endpoints
- db/schema.ts and drizzle/: schema and migrations
- lib/server.ts and lib/admin-auth.ts: admin authorisation and server helpers
- app/admin/login.tsx and app/api/admin/login/route.ts: login/logout
- lib/lead-csv.ts: export mapping and escaping
- app/page.tsx: rendered form markup
- public/app.js: form interactions
- public/content.html: companion markup; keep changes aligned with app/page.tsx
- package.json and pnpm-lock.yaml: dependencies

## Runtime secret names
See RUNTIME-SECRETS.example.txt at the package root. The hosted password and signing secret are not included. Configure them separately on the destination host. Installing dependencies or opening the ZIP does not provision a database or deploy the backend.
